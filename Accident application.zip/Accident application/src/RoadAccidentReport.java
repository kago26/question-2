

public class RoadAccidentReport extends RoadAccident {
    
    public RoadAccidentReport(String vehicleType, String city, int totalAccidents) {
        super(vehicleType, city, totalAccidents);
    }

    public void printAccidentReport() {
        System.out.println("Vehicle Accident Report");
        System.out.println("************************");
        System.out.println("Vehicle Type: " + getAccidentVehicleType());
        System.out.println("City: " + getCity());
        System.out.println("Accident Total: " + getAccidentTotal());
        System.out.println("************************");
    }
}


