


public abstract class RoadAccident implements IRoadAccidents {
    private String vehicleType;
    private String city;
    private int totalAccidents;

    public RoadAccident(String vehicleType, String city, int totalAccidents) {
        this.vehicleType = vehicleType;
        this.city = city;
        this.totalAccidents = totalAccidents;
    }

    @Override
    public String getAccidentVehicleType() {
        return vehicleType;
    }

    @Override
    public String getCity() {
        return city;
    }

    @Override
    public int getAccidentTotal() {
        return totalAccidents;
    }
}
