
import java.util.Scanner;


public class RunApplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Input vehicle type
        System.out.print("Enter the accident vehicle type: ");
        String vehicleType = scanner.nextLine();
        
        // Input city
        System.out.print("Enter the city for the vehicle accidents: ");
        String city = scanner.nextLine();
        
        // Input total accidents
        System.out.print("Enter the total " + vehicleType + " accidents for " + city + ": ");
        int totalAccidents = scanner.nextInt();
        
        // Create the accident report object
        RoadAccidentReport report = new RoadAccidentReport(vehicleType, city, totalAccidents);
        
        // Print the accident report
        report.printAccidentReport();
        
        // Close the scanner
        scanner.close();
    }
}

